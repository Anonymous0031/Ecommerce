﻿using GearUp_Sports.Models;
using Microsoft.EntityFrameworkCore;

namespace GearUp_Sports.Repository.CartRepository
{
    public class CartRepository:ICart
    {

        private readonly FinalDbContext context;
       
        public CartRepository(FinalDbContext context)
        {
            this.context = context;
        }

        

        public List<Cart> GetAllCartItems(int userId)
        {
            return context.Carts.Where(t => t.UserId == userId).ToList();
        }
        public async Task<Cart> AddToCart(int productId, int userId)
        {
            try
            {
                var productExist = await context.Carts.FirstOrDefaultAsync(t => t.ProductId == productId && t.UserId == userId);
                if (productExist == null)
                {
                    productExist = new Cart
                    {
                        ProductId = productId,
                        UserId = userId,
                        Quantity = 1,
                        ProductName = context.Products.SingleOrDefault(t => t.ProductId == productId).ProductName,
                        UnitPrice = context.Products.SingleOrDefault(t => t.ProductId == productId).Price

                    };
                    await context.Carts.AddAsync(productExist);

                }
                else
                {
                    productExist.Quantity++;

                }
                await context.SaveChangesAsync();
                return productExist;

            }
            catch
            {
                return null;
            }

           
        }

        public async Task<Cart> RemoveItem(int productId, int userId)
        {
            var result = context.Carts.FirstOrDefault(t => t.ProductId == productId && t.UserId == userId);
            if (result != null)
            {
                context.Carts.Remove(result);
                await context.SaveChangesAsync();
                return result;
            }
            return null;
        }


        public async void UpdateCartItemDB(int userId, ShoppingCartUpdate[] CartItemUpdates)
        {
            int CartItemCount = CartItemUpdates.Count();
            var myCart = GetAllCartItems(userId);
            foreach (var cartItem in myCart)
            {
                
                for (int i = 0; i < CartItemCount; i++)
                {
                    if (cartItem.ProductId == CartItemUpdates[i].ProductId)
                    {
                        if (CartItemUpdates[i].PurchaseQuantity < 1 || CartItemUpdates[i].RemoveItem == true)
                        {
                            await RemoveItem(cartItem.ProductId, userId);
                            Console.WriteLine("Removed sucessfully");
                        }
                        else
                        {
                            UpdateItem(userId, cartItem.ProductId, CartItemUpdates[i].PurchaseQuantity);
                        }
                    }
                }
            }


        }

        public int GetToTalPrice(int userId)
        {
            int sum = 0;
            var items = GetAllCartItems(userId);
            foreach (var item in items)
            {
                sum += item.UnitPrice * item.Quantity;
            }
            return sum;
        }

        public void UpdateItem(int userId, int productId, int quantity)
        {
            try
            {
                var myItem = context.Carts.FirstOrDefault(t => t.UserId == userId && t.ProductId == productId);
                if (myItem != null)
                {
                    myItem.Quantity = quantity;
                    context.SaveChanges();
                }
            }
            catch (Exception exp)
            {
                throw new Exception("error - Enable to update the cart item:");
            }
        }

        public void EmptyCart(int userId)
        {
            var cartItems = context.Carts.Where(
          c => c.UserId == userId);
            foreach (var cartItem in cartItems)
            {
                context.Carts.Remove(cartItem);
            }
                 
            context.SaveChanges();
        }

        public int GetCount(int userId)
        {
            var items = context.Carts.Where(c => c.UserId == userId);
            int count = 0;
            foreach (var item in items)
            {
                count = count + item.Quantity;
            }
                
            return count;
        }

    }

    public class ShoppingCartUpdate
    {
        public int ProductId { get; set; }
        public int PurchaseQuantity { get; set; }
        public bool RemoveItem { get; set; }
    }




}

