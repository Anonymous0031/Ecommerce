﻿using GearUp_Sports.Models;
using GearUp_Sports.Repository.CategoryRepository;
using Microsoft.EntityFrameworkCore;

namespace WalkWell.Repository.ProductRepository
{
    public class CategoryRepository : ICategory
    {
        private readonly FinalDbContext context;

        public CategoryRepository(FinalDbContext context)
        {
            this.context = context;
        }

        public async Task<IEnumerable<Category>> GetAllCategories()
        {
            return await context.Categories.ToListAsync();
        }
        public async Task<Category> GetCategoryById(int id)
        {
            return await context.Categories.FirstOrDefaultAsync(t => t.CategoryId == id);
        }

        public async Task<Category> AddCategory(Category category)
        {
            var result = await context.Categories.AddAsync(category);
            await context.SaveChangesAsync();
            return result.Entity;
        }

        public async Task<Category> UpdateCategory(int id, Category category)
        {
            var result = await context.Categories.FirstOrDefaultAsync(t => t.CategoryId == id);
            if (result != null)
            {
                result.CategoryName = category.CategoryName;
                await context.SaveChangesAsync();
                return result;
            }
            return null;
        }

        public bool CategoryExists(int id)
        {
            return context.Categories.Any(t => t.CategoryId == id);
        }

        public async Task<Category> DeleteCategory(int id)
        {
            var result = await context.Categories.FirstOrDefaultAsync(t => t.CategoryId == id);
            if (result != null)
            {
                context.Categories.Remove(result);
                await context.SaveChangesAsync();
                return result;
            }
            return null;
        }

    }
}
