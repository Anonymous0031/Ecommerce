﻿using GearUp_Sports.Models;

namespace GearUp_Sports.Repository.OrderRepository
{
    public interface IOrder
    {

        void BuyNow(int userId);
        int GetTotalAmount(int userId);

      
    
    }
}
