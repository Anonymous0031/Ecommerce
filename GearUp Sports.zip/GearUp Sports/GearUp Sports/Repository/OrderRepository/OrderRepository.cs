﻿using GearUp_Sports.Models;
using GearUp_Sports.Repository.CartRepository;
using Microsoft.EntityFrameworkCore;

namespace GearUp_Sports.Repository.OrderRepository
{
    public class OrderRepository:IOrder
    {

        private readonly FinalDbContext context;
        private readonly ICart cart;

        public OrderRepository(FinalDbContext context, ICart cart)
        {
            this.context = context;
            this.cart = cart;
        }
        public void BuyNow(int userId)
        {
            var order = new Order
            {
                UserId = userId,
                TotalAmount = GetTotalAmount(userId),
            };
            context.Orders.Add(order);
            context.SaveChanges();
        }
        public int GetTotalAmount(int userId)
        {
            return cart.GetToTalPrice(userId);
        }
       
        
        

      
       
       

    }
}
