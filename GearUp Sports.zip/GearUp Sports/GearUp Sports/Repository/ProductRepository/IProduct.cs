﻿using GearUp_Sports.Models;

namespace GearUp_Sports.Repository.ProductRepository
{
    public interface IProduct
    {

        Task<IEnumerable<Product>> GetAllProducts();

        Task<Product> GetProductById(int id);

        Task<IEnumerable<Product>> GetProductsByCategoryId(int categoryId);

        Task<Product> AddProduct(Product product);

        Task<Product> UpdateProduct(int id, Product product);
        Task<Product> DeleteProduct(int id);

        Task<List<Product>> ProductByCategory(int CategoryId);
        bool ProductExists(int id);

        Task<IEnumerable<Product>> SearchProduct(string productString);
        

       
    }
}
