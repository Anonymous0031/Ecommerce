﻿using GearUp_Sports.Models;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics.Contracts;

namespace GearUp_Sports.Repository.ProductRepository
{
    public class ProductRepository:IProduct
    {
        private readonly FinalDbContext context;

        public ProductRepository(FinalDbContext context)
        {
            this.context = context;
        }

        public async Task<IEnumerable<Product>> GetAllProducts()
        {
            return await context.Products.ToListAsync();
        }
        public async Task<Product> GetProductById(int id)
        {
            return await context.Products.FirstOrDefaultAsync(t => t.ProductId == id);
        }
        public async Task<IEnumerable<Product>> GetProductsByCategoryId(int categoryId)
        {
            return await context.Products.Where(t => t.CategoryId == categoryId).ToListAsync();
        }
        public async Task<Product> AddProduct(Product product)
        {
            var result = await context.Products.AddAsync(product);
            await context.SaveChangesAsync();
            return result.Entity;
        }

        public async Task<Product> UpdateProduct(int id, Product product)
        {
            var result = await context.Products.FirstOrDefaultAsync(t => t.ProductId == id);
            if (result != null)
            {
                result.ProductName = product.ProductName;
                result.ProductDescription = product.ProductDescription;
                result.Price = product.Price;
                result.quantity = product.quantity;
               
                result.ImageURL = product.ImageURL;
                result.CategoryId = product.CategoryId;

                await context.SaveChangesAsync();
                return result;
            }
            return null;
        }

        public bool ProductExists(int id)
        {
            return context.Products.Any(t => t.ProductId == id);
        }

        public async Task<IEnumerable<Product>> SearchProduct(string productString)
        {
            var result = context.Products.Where(p => p.ProductName.Contains(productString) || p.ProductDescription.Contains(productString));
            if (result != null)
            {
                return result;
            }
            return null;
        }

 
        public async Task<List<Product>> ProductByCategory(int CategoryId)

        {

            string FilterByCategoryId = "exec ProductByCategory @Categoryid =" + CategoryId;

            return context.Products.FromSqlRaw(FilterByCategoryId).ToList();

        }

        public async Task<Product> DeleteProduct(int id)
        {
            var res=await context.Products.FirstOrDefaultAsync(t=>t.ProductId== id);
            if(res != null)
            {
                context.Products.Remove(res);
                await context.SaveChangesAsync();
                return res;
            }
            return null;
        }

     

      
    }
}
