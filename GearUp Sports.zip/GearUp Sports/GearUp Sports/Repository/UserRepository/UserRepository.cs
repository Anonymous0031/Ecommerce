﻿using GearUp_Sports.Dto;
using GearUp_Sports.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace GearUp_Sports.Repository.UserRepository
{
    public class UserRepository:IUser
    {

        private readonly FinalDbContext _context;
        private readonly IConfiguration configuration;

        public UserRepository(FinalDbContext context, IConfiguration configuration)
        {
            this._context = context;
            this.configuration = configuration;
        }

        public async Task<IEnumerable<UserDetailsDto>> GetAll()
        {
            List<User> user = await _context.Users.ToListAsync();
            List<UserDetailsDto> details = new List<UserDetailsDto>();
            foreach (var userdetails in user)
            {
                UserDetailsDto detail = new UserDetailsDto();
                detail.UserId = userdetails.UserId;
                detail.FirstName = userdetails.FirstName;
                detail.LastName = userdetails.LastName;
                detail.Email = userdetails.Email;
                detail.UserType = userdetails.UserType;
                detail.MobileNumber = userdetails.MobileNumber;
                detail.Address = userdetails.Address;
                details.Add(detail);
            }
            return details;
        }
        public async Task<User> AddUserAsync(User user)
        {
            if (UserExist(user))
            {
                return null;
            }
            else
            {
                var result = await _context.Users.AddAsync(user);
                await _context.SaveChangesAsync();
                return result.Entity;
            }
        }

        public string Login(string email, string password)
        {
            var userExist = _context.Users.FirstOrDefault(t => t.Email == email && t.Password == password);
            if (userExist != null)
            {
                var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration["Jwt:Key"]));
                var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
                var claims = new[]
                {
             new Claim(ClaimTypes.Email,userExist.Email),
             new Claim("UserId",userExist.UserId.ToString()),
             new Claim(ClaimTypes.Role,userExist.UserType)
         };
                var token = new JwtSecurityToken(configuration["Jwt:Issuer"], configuration["Jwt:Audience"], claims, expires: DateTime.Now.AddMinutes(30), signingCredentials: credentials);
                return new JwtSecurityTokenHandler().WriteToken(token);

            }
            return null;
        }

        public async Task<User> UpdateUserDetail(int id, User user)
        {
            var result = await _context.Users.FirstOrDefaultAsync(t => t.UserId == id);
            if (result != null)
            {
                result.FirstName = user.FirstName;
                result.LastName = user.LastName;
                result.Email = user.Email;
                result.Password = user.Password;
                result.MobileNumber = user.MobileNumber;
                result.Address = user.Address;

                await _context.SaveChangesAsync();
                return result;
            }
            return null;
        }

        private bool UserExist(User user)
        {
            return _context.Users.Any(t => t.Email == user.Email);
        }

    }
}
