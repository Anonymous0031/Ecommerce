﻿using GearUp_Sports.Dto;
using GearUp_Sports.Models;

namespace GearUp_Sports.Repository.UserRepository
{
    public interface IUser
    {

        Task<IEnumerable<UserDetailsDto>> GetAll();

        Task<User> AddUserAsync(User user);

     
        string Login(string email, string password);
        Task<User> UpdateUserDetail(int id, User user);
    }
}
