﻿using GearUp_Sports.Models;
using WalkWell.Repository.ProductRepository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using GearUp_Sports.Repository.ProductRepository;

namespace GearUp_Sports.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly IProduct _product;

        public ProductsController(IProduct product)
        {
            this._product = product;
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Product>>> GetAllProducts()
        {
            var result = await _product.GetAllProducts();
            
            return Ok(result);
        }

        [HttpGet("{id:int}")]
        public async Task<ActionResult<Product>> GetProductById(int id)
        {
            var product = await _product.GetProductById(id);

            if (product == null)
            {
                return NotFound();
            }

            return product;
        }

        [HttpGet("GetAllProductsByCategoryId")]
        public async Task<ActionResult<IEnumerable<Product>>> GetProductsByCategoryId(int categoryId)
        {
            var result = await _product.GetProductsByCategoryId(categoryId);
            if (result == null)
            {
                return NotFound();
            }
            return Ok(result);
        }

        [HttpPut("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateProduct(int id, Product product)
        {

            try
            {
                await _product.UpdateProduct(id, product);

            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ProductExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<Product>> AddProduct(Product product)
        {
            var result = await _product.AddProduct(product);

            return Ok(result);
         
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            var product = await _product.DeleteProduct(id);
            if (product == null)
            {
                return NotFound();
            }

            return NoContent();
        }

        private bool ProductExists(int id)
        {
            return _product.ProductExists(id);
        }

        [HttpGet]
        [Route("search/{searchItem}")]
        public async Task<ActionResult<IEnumerable<Product>>> SearchProductByNameOrDesc(string searchItem)
        {
            var result = await _product.SearchProduct(searchItem);
            if (result != null)
            {
                return Ok(result);
            }
            return NoContent();
        }

        [HttpGet("GetAllProductsByCategorystoreprocedure")]
        public async Task<ActionResult<IEnumerable<Product>>> GetProductsByCategory(int categoryId)
        {
            var result = await _product.GetProductsByCategoryId(categoryId);
            if (result == null)
            {
                return NotFound("Not Found");
            }
            return Ok(result);
        }



    }
}
