﻿using GearUp_Sports.Models;
using GearUp_Sports.Repository.UserRepository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace GearUp_Sports.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {

        private readonly IUser _user;
        public UserController(IUser userInterface)
        {
            this._user = userInterface;

        }



        [HttpGet]
      [Authorize(Roles ="Admin")]
        public async Task<ActionResult<User>> GetAllUsers()
        {
            var result = await _user.GetAll();
            if (result != null)
            {
                return Ok(result);
            }
            return NotFound("No user found");
        }

        [HttpPut("{id:int}")]
        public async Task<ActionResult<User>> UpdateUser(int id, [FromBody] User user)
        {
            var result = await _user.UpdateUserDetail(id, user);
            if (result != null)
            {
                return Ok(result);
            }
            return BadRequest();
        }

        [HttpPost("login")]
        public string Login(string email, string password)
        {
            var result = _user.Login(email, password);

            if (result != null)
            {
                return result;
            }
            return null;
        }

        [HttpPost]
        public async Task<ActionResult<User>> AddUser([FromBody] User user)
        {
            var result = await _user.AddUserAsync(user);
            if (result != null)
            {
                return Ok(result);
            }
            return BadRequest("User already exist.Please login");

        }

    }
}
