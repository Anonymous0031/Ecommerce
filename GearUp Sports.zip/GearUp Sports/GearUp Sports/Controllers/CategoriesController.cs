﻿using GearUp_Sports.Models;
using GearUp_Sports.Repository.CategoryRepository;
using GearUp_Sports.Repository.ProductRepository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GearUp_Sports.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoriesController : ControllerBase
    {
        private readonly ICategory _category;

        public CategoriesController(ICategory category)
        {
            this._category = category;
        }

       
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Category>>> GetAllCategories()
        {
            var result = await _category.GetAllCategories();
            if (result != null)
            {
                return Ok(result);
            }
            return NoContent();
        }

       
       


        [HttpPut("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> PutCategory(int id, [FromBody] Category category)
        {
        
            try
            {
                await _category.UpdateCategory(id, category);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CategoryExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

  
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<Category>> PostCategory([FromBody] Category category)
        {
           var result= await _category.AddCategory(category);

            return Ok(result);
        }

       
        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteCategory(int id)
        {
            var category = await _category.DeleteCategory(id);
            if (category == null)
            {
                return NotFound("Not Found Category id");
            }


            return Ok("Deleted successfully");
        }

        private bool CategoryExists(int id)
        {
            return _category.CategoryExists(id);
        }
    }
}
