﻿using GearUp_Sports.Repository.OrderRepository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace GearUp_Sports.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrdersController : ControllerBase
    {
        private readonly IOrder _order;
        public OrdersController(IOrder order)
        {
            this._order = order;

        }
        [HttpPost]
        [Route("AddOrder")]
        //[Authorize(Roles ="User")]

        public IActionResult BuyNow(int userId)
        {
            _order.BuyNow(userId);
            return Ok();
        }
       

        [HttpGet]
        [Route("GetTotalAmount")]

        public int GetTotalAmount(int userId)
        {
          var result1= _order.GetTotalAmount(userId);
            return result1;
        }

     
    }

   
}
